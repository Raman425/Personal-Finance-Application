package com.example.personalfinancemanagementapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class BudgetActivity extends AppCompatActivity {

    private TextView textViewBudgetAmount;
    private EditText editTextBudgetAmount;
    private Button updateBudgetButton;
    private TextView textViewCategory1;
    private TextView textViewCategory2;
    private TextView textViewSpentCategory1;
    private TextView textViewSpentCategory2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget);

        textViewBudgetAmount = findViewById(R.id.textViewBudgetAmount);
        editTextBudgetAmount = findViewById(R.id.editTextBudgetAmount);
        updateBudgetButton = findViewById(R.id.updateBudgetButton);
        textViewCategory1 = findViewById(R.id.textViewCategory1);
        textViewCategory2 = findViewById(R.id.textViewCategory2);
        textViewSpentCategory1 = findViewById(R.id.textViewSpentCategory1);
        textViewSpentCategory2 = findViewById(R.id.textViewSpentCategory2);

        // Initial setup with default values
        updateUI(1000, 300, 150, 400, 300);

        updateBudgetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve and validate user input
                String budgetInput = editTextBudgetAmount.getText().toString();
                if (!budgetInput.isEmpty()) {
                    double newBudgetAmount = Double.parseDouble(budgetInput);
                    // Update the UI with the new values (you can also save this to a database or shared preferences)
                    updateUI(newBudgetAmount, 300, 150, 400, 300);
                }
            }
        });
    }

    private void updateUI(double budgetAmount, double allocatedCategory1, double spentCategory1, double allocatedCategory2, double spentCategory2) {
        textViewBudgetAmount.setText("Monthly Budget: $" + budgetAmount);
        textViewCategory1.setText("Allocated Amount: $" + allocatedCategory1);
        textViewSpentCategory1.setText("Spent Amount: $" + spentCategory1);
        textViewCategory2.setText("Allocated Amount: $" + allocatedCategory2);
        textViewSpentCategory2.setText("Spent Amount: $" + spentCategory2);
    }
}
