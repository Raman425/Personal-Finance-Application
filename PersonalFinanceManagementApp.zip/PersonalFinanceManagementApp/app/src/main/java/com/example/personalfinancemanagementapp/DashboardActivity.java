package com.example.personalfinancemanagementapp;

import android.content.Context;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.io.IOException;

public class DashboardActivity extends AppCompatActivity {

    private TextView textViewIncome, textViewExpenses, textViewSavings, textViewInvestments;
    private ImageView lineChartPlaceholder;

    private double defaultIncome = 10000.0;
    private double defaultExpenses = 7000.0;
    private double defaultSavings = 3000.0;
    private double defaultInvestments = 2000.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        textViewIncome = findViewById(R.id.textViewIncome);
        textViewExpenses = findViewById(R.id.textViewExpenses);
        textViewSavings = findViewById(R.id.textViewSavings);
        textViewInvestments = findViewById(R.id.textViewInvestments);
        lineChartPlaceholder = findViewById(R.id.lineChartPlaceholder);

        // Load and display the default financial data
        loadDefaultData();

        // Save the default financial data into a .txt file
        saveDataToFile("financial_data.txt");

        // Placeholder for loading a chart (optional)
        loadChart();
    }

    // Load default data into TextViews
    private void loadDefaultData() {
        textViewIncome.setText("Total Income: $" + defaultIncome);
        textViewExpenses.setText("Total Expenses: $" + defaultExpenses);
        textViewSavings.setText("Total Savings: $" + defaultSavings);
        textViewInvestments.setText("Total Investments: $" + defaultInvestments);
    }

    // Save financial data into a .txt file
    private void saveDataToFile(String fileName) {
        String financialData = "Income: $" + defaultIncome + "\n" +
                "Expenses: $" + defaultExpenses + "\n" +
                "Savings: $" + defaultSavings + "\n" +
                "Investments: $" + defaultInvestments;

        FileOutputStream fos = null;
        try {
            fos = openFileOutput(fileName, Context.MODE_PRIVATE);
            fos.write(financialData.getBytes());
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Placeholder for chart loading logic (you can later implement actual chart drawing)
    private void loadChart() {
        // For now, the placeholder will show an image (line_chart_placeholder).
        // Later, you can integrate a chart library like MPAndroidChart.
        lineChartPlaceholder.setImageResource(R.drawable.line_chart_placeholder);
    }
}
