package com.example.personalfinancemanagementapp;


import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class GoalActivity extends AppCompatActivity {

    // Declare UI elements for the first goal
    private TextView goalName1, goalAmount1, deadline1, totalSaved, totalNeeded, estimatedTime;
    private ProgressBar progress1;
    private Button viewMore1;

    // Declare UI elements for the second goal
    private TextView goalName2, goalAmount2, deadline2;
    private ProgressBar progress2;
    private Button viewMore2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);

        // Initialize the UI elements for the first goal
        goalName1 = findViewById(R.id.goalName1);
        goalAmount1 = findViewById(R.id.goalAmount1);
        deadline1 = findViewById(R.id.deadline1);
        progress1 = findViewById(R.id.progress1);
        viewMore1 = findViewById(R.id.viewMore1);

        // Initialize the UI elements for the second goal
        goalName2 = findViewById(R.id.goalName2);
        goalAmount2 = findViewById(R.id.goalAmount2);
        deadline2 = findViewById(R.id.deadline2);
        progress2 = findViewById(R.id.progress2);
        viewMore2 = findViewById(R.id.viewMore2);

        // Initialize the summary section elements
        totalSaved = findViewById(R.id.totalSaved);
        totalNeeded = findViewById(R.id.totalNeeded);
        estimatedTime = findViewById(R.id.estimatedTime);

        // Load goal data (simulated here with static data)
        loadGoalData();
    }

    // Method to load and display goal data
    private void loadGoalData() {
        // First Goal Data (could be retrieved from a database or API)
        String goal1Name = "Save for a Vacation";
        String goal1Amount = "$3000";
        String goal1Deadline = "December 2022";
        int goal1Progress = 40;

        // Set values for the first goal
        goalName1.setText(goal1Name);
        goalAmount1.setText("Target Amount: " + goal1Amount);
        deadline1.setText("Deadline: " + goal1Deadline);
        progress1.setProgress(goal1Progress);

        // Set listener for the first goal's "View More" button
        viewMore1.setOnClickListener(v -> {
        });

        // Second Goal Data (could be retrieved from a database or API)
        String goal2Name = "Pay Off Credit Card Debt";
        String goal2Amount = "$2000";
        String goal2Deadline = "March 2023";
        int goal2Progress = 30;

        // Set values for the second goal
        goalName2.setText(goal2Name);
        goalAmount2.setText("Target Amount: " + goal2Amount);
        deadline2.setText("Deadline: " + goal2Deadline);
        progress2.setProgress(goal2Progress);

        // Set listener for the second goal's "View More" button
        viewMore2.setOnClickListener(v -> {
        });

        String totalSavedAmount = "$1300";
        String totalNeededAmount = "$5000";
        String estimatedTimeText = "6 months";


        totalSaved.setText("Total Saved: " + totalSavedAmount);
        totalNeeded.setText("Total Needed: " + totalNeededAmount);
        estimatedTime.setText("Estimated Time: " + estimatedTimeText);
    }
}
