package com.example.personalfinancemanagementapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;
    private TextView textViewRegister;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        textViewRegister = findViewById(R.id.textViewRegister);

        databaseHelper = new DatabaseHelper(this);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                if (!username.isEmpty() && !password.isEmpty()) {
                    new LoginUserTask().execute(username, password);
                } else {
                    Toast.makeText(LoginActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        textViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    private class LoginUserTask extends AsyncTask<String, Void, Boolean> {
        private String errorMessage = "";

        @Override
        protected Boolean doInBackground(String... params) {
            String username = params[0];
            String password = params[1];
            boolean loginSuccess = false;

            try {
                SQLiteDatabase db = databaseHelper.getReadableDatabase();
                String query = "SELECT * FROM " + DatabaseHelper.TABLE_USERS + " WHERE " +
                        DatabaseHelper.COLUMN_USERNAME + " = ? AND " +
                        DatabaseHelper.COLUMN_PASSWORD + " = ?";
                Cursor cursor = db.rawQuery(query, new String[]{username, password});

                if (cursor.moveToFirst()) {
                    loginSuccess = true;
                }

                cursor.close();
                db.close();
            } catch (Exception e) {
                errorMessage = e.getMessage();
            }

            return loginSuccess;
        }

        @Override
        protected void onPostExecute(Boolean loginSuccess) {
            if (loginSuccess) {
                Intent intent = new Intent(LoginActivity.this, MainMenuActivity.class);
                startActivity(intent);
                finish(); // Close login activity
            } else {
                Toast.makeText(LoginActivity.this, "Invalid username or password" + (errorMessage.isEmpty() ? "" : ": " + errorMessage), Toast.LENGTH_SHORT).show();
            }
        }
    }
}
