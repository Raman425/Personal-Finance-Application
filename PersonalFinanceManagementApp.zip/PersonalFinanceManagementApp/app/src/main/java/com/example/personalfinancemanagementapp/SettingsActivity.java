package com.example.personalfinancemanagementapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private EditText editTextOldUsername, editTextNewUsername, editTextNewPassword;
    private Button buttonSave;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize views
        editTextOldUsername = findViewById(R.id.editTextOldUsername);
        editTextNewUsername = findViewById(R.id.editTextNewUsername);
        editTextNewPassword = findViewById(R.id.editTextNewPassword);
        buttonSave = findViewById(R.id.buttonSave);

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Handle Save button click
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String oldUsername = editTextOldUsername.getText().toString().trim();
                String newUsername = editTextNewUsername.getText().toString().trim();
                String newPassword = editTextNewPassword.getText().toString().trim();

                if (validateInputs(oldUsername, newUsername, newPassword)) {
                    // Check if old username exists in the database
                    Cursor cursor = databaseHelper.getUser(oldUsername);
                    if (cursor != null && cursor.getCount() > 0) {
                        // Update the user information
                        boolean isUpdated = databaseHelper.updateUser(oldUsername, newUsername, newPassword);
                        if (isUpdated) {
                            Toast.makeText(SettingsActivity.this, "Settings saved successfully!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(SettingsActivity.this, "Failed to update settings.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(SettingsActivity.this, "Old username not found.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private boolean validateInputs(String oldUsername, String newUsername, String newPassword) {
        if (oldUsername.isEmpty() || newUsername.isEmpty() || newPassword.isEmpty()) {
            Toast.makeText(this, "Please fill out all fields.", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (newPassword.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters long.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
