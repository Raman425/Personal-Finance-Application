package com.example.personalfinancemanagementapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddEditBudgetActivity extends AppCompatActivity {

    private EditText editTextCategory1Amount;
    private EditText editTextCategory2Amount;
    private Button buttonSaveBudget;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_budget);

        editTextCategory1Amount = findViewById(R.id.editTextCategory1Amount);
        editTextCategory2Amount = findViewById(R.id.editTextCategory2Amount);
        buttonSaveBudget = findViewById(R.id.buttonSaveBudget);

        // Get the current budget values if passed from previous activity
        Intent intent = getIntent();
        String category1Amount = intent.getStringExtra("category1Amount");
        String category2Amount = intent.getStringExtra("category2Amount");

        if (category1Amount != null) {
            editTextCategory1Amount.setText(category1Amount);
        }
        if (category2Amount != null) {
            editTextCategory2Amount.setText(category2Amount);
        }

        // Save the budget and pass back the data
        buttonSaveBudget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newCategory1Amount = editTextCategory1Amount.getText().toString();
                String newCategory2Amount = editTextCategory2Amount.getText().toString();

                if (newCategory1Amount.isEmpty() || newCategory2Amount.isEmpty()) {
                    Toast.makeText(AddEditBudgetActivity.this, "Please enter all amounts", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Create an Intent to pass back the data
                Intent resultIntent = new Intent();
                resultIntent.putExtra("newCategory1Amount", newCategory1Amount);
                resultIntent.putExtra("newCategory2Amount", newCategory2Amount);
                setResult(RESULT_OK, resultIntent);
                finish(); // Go back to the BudgetActivity
            }
        });
    }
}
