package com.example.personalfinancemanagementapp;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ExpenseActivity extends AppCompatActivity {

    private EditText editTextAmount, editTextDate, editTextNotes;
    private Spinner spinnerCategory;
    private Button buttonAddExpense;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense);

        // Initialize views
        editTextAmount = findViewById(R.id.editTextAmount);
        editTextDate = findViewById(R.id.editTextDate);
        editTextNotes = findViewById(R.id.editTextNotes);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        buttonAddExpense = findViewById(R.id.buttonAddExpense);
        databaseHelper = new DatabaseHelper(this);

        buttonAddExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amount = editTextAmount.getText().toString().trim();
                String date = editTextDate.getText().toString().trim();
                String notes = editTextNotes.getText().toString().trim();
                String category = spinnerCategory.getSelectedItem().toString();

                if (!amount.isEmpty() && !date.isEmpty() && !category.isEmpty()) {
                    addExpense(amount, category, date, notes);
                } else {
                    Toast.makeText(ExpenseActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void addExpense(String amount, String category, String date, String notes) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        String query = "INSERT INTO " + DatabaseHelper.TABLE_EXPENSES + " (" +
                DatabaseHelper.COLUMN_EXPENSE_AMOUNT + ", " +
                DatabaseHelper.COLUMN_EXPENSE_CATEGORY + ", " +
                DatabaseHelper.COLUMN_EXPENSE_DATE + ", " +
                DatabaseHelper.COLUMN_EXPENSE_NOTES + ") VALUES (?, ?, ?, ?)";
        db.execSQL(query, new Object[]{Double.parseDouble(amount), category, date, notes});
        Toast.makeText(ExpenseActivity.this, "Expense added", Toast.LENGTH_SHORT).show();
        db.close();
    }
}
