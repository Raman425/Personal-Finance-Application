package com.example.personalfinancemanagementapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "financeDB.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    public static final String TABLE_EXPENSES = "expenses";
    public static final String COLUMN_EXPENSE_ID = "expense_id";
    public static final String COLUMN_EXPENSE_AMOUNT = "amount";
    public static final String COLUMN_EXPENSE_CATEGORY = "category";
    public static final String COLUMN_EXPENSE_DATE = "expense_date";
    public static final String COLUMN_EXPENSE_NOTES = "notes";  // Added notes column

    public static final String TABLE_BUDGET = "budget";
    public static final String COLUMN_BUDGET_ID = "budget_id";
    public static final String COLUMN_BUDGET_AMOUNT = "budget_amount";
    public static final String COLUMN_BUDGET_MONTH = "budget_month";

    public static final String TABLE_GOALS = "goals";
    public static final String COLUMN_GOAL_ID = "goal_id";
    public static final String COLUMN_GOAL_NAME = "goal_name";
    public static final String COLUMN_GOAL_AMOUNT = "goal_amount";
    public static final String COLUMN_GOAL_PROGRESS = "goal_progress";

    private static final String TABLE_CREATE_USERS =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT UNIQUE, " +
                    COLUMN_PASSWORD + " TEXT" +
                    ");";

    private static final String TABLE_CREATE_EXPENSES =
            "CREATE TABLE " + TABLE_EXPENSES + " (" +
                    COLUMN_EXPENSE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_EXPENSE_AMOUNT + " REAL, " +
                    COLUMN_EXPENSE_CATEGORY + " TEXT, " +
                    COLUMN_EXPENSE_DATE + " TEXT, " +
                    COLUMN_EXPENSE_NOTES + " TEXT" +  // Added notes column
                    ");";

    private static final String TABLE_CREATE_BUDGET =
            "CREATE TABLE " + TABLE_BUDGET + " (" +
                    COLUMN_BUDGET_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_BUDGET_AMOUNT + " REAL, " +
                    COLUMN_BUDGET_MONTH + " TEXT" +
                    ");";

    private static final String TABLE_CREATE_GOALS =
            "CREATE TABLE " + TABLE_GOALS + " (" +
                    COLUMN_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_GOAL_NAME + " TEXT, " +
                    COLUMN_GOAL_AMOUNT + " REAL, " +
                    COLUMN_GOAL_PROGRESS + " REAL" +
                    ");";

    private static final String INSERT_USERS =
            "INSERT INTO " + TABLE_USERS + " (" +
                    COLUMN_USERNAME + ", " +
                    COLUMN_PASSWORD + ") VALUES " +
                    "('user1', 'password1'), " +
                    "('user2', 'password2');";

    private static final String INSERT_EXPENSES =
            "INSERT INTO " + TABLE_EXPENSES + " (" +
                    COLUMN_EXPENSE_AMOUNT + ", " +
                    COLUMN_EXPENSE_CATEGORY + ", " +
                    COLUMN_EXPENSE_DATE + ", " +
                    COLUMN_EXPENSE_NOTES + ") VALUES " +
                    "(100.0, 'Groceries', '2024-09-01', 'Weekly groceries'), " +
                    "(50.0, 'Utilities', '2024-09-05', 'Electric bill'), " +
                    "(75.0, 'Entertainment', '2024-09-10', 'Movie tickets'), " +
                    "(200.0, 'Rent', '2024-09-15', 'Monthly rent');";

    private static final String INSERT_BUDGET =
            "INSERT INTO " + TABLE_BUDGET + " (" +
                    COLUMN_BUDGET_AMOUNT + ", " +
                    COLUMN_BUDGET_MONTH + ") VALUES " +
                    "(3000.0, 'September 2024'), " +
                    "(3500.0, 'October 2024');";

    private static final String INSERT_GOALS =
            "INSERT INTO " + TABLE_GOALS + " (" +
                    COLUMN_GOAL_NAME + ", " +
                    COLUMN_GOAL_AMOUNT + ", " +
                    COLUMN_GOAL_PROGRESS + ") VALUES " +
                    "('Emergency Fund', 1000.0, 250.0), " +
                    "('Vacation', 2000.0, 500.0), " +
                    "('New Car', 5000.0, 1000.0);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE_USERS);
        db.execSQL(TABLE_CREATE_EXPENSES);
        db.execSQL(TABLE_CREATE_BUDGET);
        db.execSQL(TABLE_CREATE_GOALS);

        // Insert sample data
        db.execSQL(INSERT_USERS);
        db.execSQL(INSERT_EXPENSES);
        db.execSQL(INSERT_BUDGET);
        db.execSQL(INSERT_GOALS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXPENSES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BUDGET);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOALS);
        onCreate(db);
    }

    public Cursor getUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_USERS, null, COLUMN_USERNAME + "=?", new String[]{username}, null, null, null);
    }

    public boolean updateUser(String oldUsername, String newUsername, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USERNAME, newUsername);
        contentValues.put(COLUMN_PASSWORD, newPassword);

        int result = db.update(TABLE_USERS, contentValues, COLUMN_USERNAME + "=?", new String[]{oldUsername});
        return result > 0;
    }
}
